#include <iostream>
using namespace std;
#include <Windows.h>

void gotoxy(int x, int y){
	
	COORD coord;
	coord.X = x;
	coord.Y = y;
	
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
	
}
 
 double max();
 int main()
{	
		cout<<max();
	return 0;
}


	

double max()
{
	
        int n, i,j,c;
    	char main='y';
    
    
    while (main=='Y'||main=='y')
    {	float high=0,sechigh=0,low=99999, seclow=99999;
	    gotoxy (30,1);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
		gotoxy (30,2);cout<<"\xBA                                                  \xBA";
		gotoxy (30,3);cout<<"\xBA         Enter the size of the array              \xBA";
		gotoxy (30,4);cout<<"\xBA       Cannot be equal or less than to 1          \xBA";
		gotoxy (30,5);cout<<"\xBA                                                  \xBA";
		gotoxy (30,6);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
		
		float arr[n];
		gotoxy (30,7);cout<<">> ";
		gotoxy (32,7);cin >> n;
		if(n==1){
			gotoxy (30,5);cout<<"System Error: Can't find Largest and/or Lowest Number if there's only one value.";
			return 0;
		}
		system("CLS");
		
		for (i = 0; i<n; ++i)
		{
			gotoxy (30,1);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			gotoxy (30,2);cout<<"\xBA                                                  \xBA";
			gotoxy (30,3);cout<<"\xBA                Enter index ["<<i<<"]                   \xBA";
			gotoxy (30,4);cout<<"\xBA                                                  \xBA";
			gotoxy (30,5);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
			
			gotoxy (30,6);cout<<">> ";
        	gotoxy (32,6);cin >> arr[i];
        	system("CLS");
    	}
    	
         for (i = 0; i<n; ++i)
        {        	
              if (arr[i]>high)
              {
                     high = arr[i];
              }
        }
       		//finding second largset
         for (i = 0; i<n; ++i)
        {
              if (arr[i]>sechigh)
              {
                     if (arr[i] == high)
                           continue;              //Ignoring largest in order to get second largest
                     sechigh = arr[i];
              }
              
		}
		for (i=0;i<n;++i){
			if (low>arr[i])
              {
                     low = arr[i];
              }
		}
		
		for (i=0;i<n;++i)
		{
			if (seclow>arr[i])
              {
                     if (arr[i] == low)
                           continue;              //Ignoring largest in order to get second largest
                     seclow = arr[i];
              }
		}
		system("CLS");
		
		cout<<"Entered Values>>";
		for (i = 0; i<n; ++i)
			{
			cout<<"|"<<arr[i]<< "| ";
			}
			
	        system("CLS");

       		gotoxy (30,5);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			gotoxy (30,6);cout<<"\xBA             Largest number: "<<high<<"                     \xBA\xDB\xDB";
			gotoxy (30,7);cout<<"\xBA	          Second Largest number: "<<sechigh<<"                \xBA\xDB\xDB";
			gotoxy (30,8);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\xDB\xDB";	
			gotoxy (30,9);cout<<"   \xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB\xDB";
    	
			gotoxy (0,11); system("PAUSE");
			system("CLS");    
    		gotoxy (30,1);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			gotoxy (30,2);cout<<"\xBA                                                  \xBA";
			gotoxy (30,3);cout<<"\xBA        Do you wanna go back to try again?        \xBA";
			gotoxy (30,4);cout<<"\xBA                  Press [Y] if Yes                \xBA";
			gotoxy (30,5);cout<<"\xBA                                                  \xBA";
			gotoxy (30,6);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
	        gotoxy (30,7);cout<<">>";
	       
			gotoxy (32,7);cin>>main;
			 system("CLS");
		
}
}
