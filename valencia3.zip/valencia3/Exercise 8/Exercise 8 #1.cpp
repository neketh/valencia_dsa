#include <algorithm>
#include <iostream> // Input and output
#include <string> // String usage
#include <fstream> // Text output (aesthetics)
#include <cmath>
#include <windows.h> // gotoxy() (replica of Turbo C++)
#include <vector>
#include <cstdlib>
#include <ctype.h>
#include <iomanip>
#define MAX 100000

using namespace std;

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void textout(string filename){ // filestreaming text files
	system("cls");
	string line;
	ifstream file;
	file.open(filename.c_str());
	if (file.is_open()) {
		while (getline(file, line)) {
			cout << line << endl;
		}
		file.close();
	}
}

struct CDAccount{
	double balance;
	double interestRate;
	int term;
};


void newLine(){
    char s;
	do{cin.get(s);}while(s!='\n');
}




CDAccount doubleInterest(CDAccount oldAccount){
	CDAccount temp;
	temp=oldAccount;
	temp.interestRate=2*oldAccount.interestRate;
	return temp;
}

void accountBalance (CDAccount& _account){
	double rateFraction, interest;
	rateFraction = _account.interestRate/100.0;
	interest= _account.balance*(rateFraction*(_account.term/12));
	_account.balance=_account.balance+interest;
}




void error(){ // Display message for invalid inputs

	system("cls");
	textout("text\\error.txt");
	system("pause");
}

string tryAgain; // global variable if the user wants to try again

int main(){
    system("color 0a");     // Selection menu
a:	system("mode 104, 35"); // Change console text resolution (W10)
	textout("text\\title.txt");
	gotoxy(52, 13);
	string choice = "";
	string userInputs = "";
	getline(cin, choice); // getline() for accommodating spaces (error handling)

b:	system("cls");
	if (choice == "1"){
        system("cls");

       CDAccount account;
        cout <<"Enter account balance : PHP ";
        cin >>account.balance;
        cout <<"Enter account interest: ";
        cin >>account.interestRate;
        cout << "Enter the number of months until maturity: ";
        cin >>account.term;

        accountBalance(account);

        cout << "\nOld Account \n"
		<< "When your CD matures in \n"
		<<account.term<< " months,\n"
		<<"it will have a balance of PHP "
		<<account.balance<<endl;

        CDAccount accountNew;
        accountNew=doubleInterest(account);
        accountBalance(accountNew);

        cout <<"\nNew Account \n"
		<<"When your CD matures in "
		<< accountNew.term << " months,\n"
		<< "it will have a balance of PHP "
		<< accountNew.balance <<endl;
	}


    else if(choice == "2"){
        exit(0); // exit program
    }
	else{ // all invalid inputs are error including white spaces
        error();
        goto a;
	}

}





