#include <iostream>
#include <string.h>
using namespace std;

int main() 
{
	char str1[99], str2[99];
	
	cout<<"Welcome!\nInput #1: ";
	cin>>str1;
	cout<<"\nInput #2 ";
	cin>>str2;
	system("cls");
	strcat(str1,str2);
	
	cout<<"After concatinated: "<<str1;
	cout<<"\n";
	system("pause");
	
	
	
	
	return 0;
}
