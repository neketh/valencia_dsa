#include <iostream>
using namespace std;
 
int compare_string(char*, char*);
 
main()
{
    char first[100], second[100], result;
 
    cout<<"Enter first string\n";
    cin>>first;
 
    cout<<"\nEnter second string\n";
    cin>>second;
    system("cls");
 
    result = compare_string(first, second);
 
    if ( result == 0 )
       cout<<"Both strings are same.\n";
    else
       cout<<"Entered strings are not equal.\n";
 
    return 0;
}
 
int compare_string(char *first, char *second)
{
   while(*first==*second)
   {
      if ( *first == '\0' || *second == '\0' )
         break;
 
      first++;
      second++;
   }
   if( *first == '\0' && *second == '\0' )
      return 0;
   else
      return -1;
}
