#include <iostream>
using namespace std;

void copy_string(char*, char*);

main()
{
    char source[100], target[100];  
    cout<<"Enter original string\n";    
    cin>>target;
    cout<<"Enter string to be copied: \n";
   	cin>>source;
   	system("pause");
   	system("cls");
   	
    copy_string(target, source);  
	 
    cout<<"\nOriginal input after being copied : "<<target<<"\n";   
	system("pause"); 
    return 0;
}

void copy_string(char *target, char *source)
{
    while(*source)
    {
        *target = *source;        
        source++;        
        target++;
    }    
    *target = '\0';
}
