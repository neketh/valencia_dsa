#include <iostream>
using namespace std;

int main()
{
	FILE *fp;
	fp=fopen("c:\\Users\\ACER\\Desktop\\DSA\\sample.txt","a");
	
	if(!fp)
	{
		cout<< ("Cannot open file.\n");
		system("pause");
		exit(1);
	}
	
	fputs("\nsample string 1\n",fp);
	fputs("sample string 2\n",fp);
	
	fclose(fp);
	return 0;
}
