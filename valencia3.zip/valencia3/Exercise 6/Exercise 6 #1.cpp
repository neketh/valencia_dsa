#include <iostream>
using namespace std;

int main()
{
	FILE *fp;
	fp = fopen("c:\\Users\\ACER\\Desktop\\DSA\\sample.txt","w");
	
	//Check permission if you can write a file
	if(!fp)
	{
		cout<< ("Cannot open file.\n");
		system("pause");
		exit(1);
	}
	
	//Prints the character ASCII value from 65-90 (A-Z) to a file
	for(int i=65; i<91; i++)
	fputc(i,fp);
	
	fclose(fp);
	return 0;
}
