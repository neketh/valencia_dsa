#include <iostream>
using namespace std;


struct Student
{
	int id;
	char name [30];
	double score1,score2,score3,average;
	string remarks;
};

void newLine();

int main() 
{
	Student s;
	cout<<"Enter Student Information\n";
	cout<<"Student ID: ";
	cin>>s.id;
	cout<<"\nStudent Name: ";
	newLine();
	cin.getline(s.name,29);
	cout<<"\nQuiz Scores: ";
	cout<<"\nQuiz 1: ";
	cin>>s.score1;
	cout<<"\nQuiz 2: ";
	cin>>s.score2;
	cout<<"\nQuiz 3: ";
	cin>>s.score3;
	system("cls");	
	
	s.average=(s.score1+s.score2+s.score3)/3;
	
	cout<<"Student Record";
	cout<<"\nStudent ID: "<<s.id;
	cout<<"\nStudent Name: "<<s.name;
	cout<<"\nAverage: "<<s.average;
	if (s.average>=75)
		{
			cout<<"\nRemarks: Passed";
		}
	else
		{
			cout<<"\nRemarks: Failed";
		}
	
	return 0;
}

void newLine()
{
	char s;
	do 
	{
		cin.get(s);
	}
	while(s!='\n');
}






